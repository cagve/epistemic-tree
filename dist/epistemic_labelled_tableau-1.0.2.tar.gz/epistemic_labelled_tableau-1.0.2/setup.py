from setuptools import setup
setup(
    name='Epistemic tableaux',
    version='1.0.2',
    description='A tool for find a model of the formulas',
    keywords='epistemic logic',
)

