__app_name__ = "Epistemic Prefixed Tableaux"
__version__ = "0.1.0"
